function idx = sh_index(l, m)
    idx = l^2 + m + l + 1;
end